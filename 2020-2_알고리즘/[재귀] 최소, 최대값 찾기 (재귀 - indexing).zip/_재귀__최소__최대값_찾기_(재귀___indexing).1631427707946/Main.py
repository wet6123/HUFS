def min_max2(A, left, right):
	n = right - left
	
	if left == right:
		return A[left], A[left]
	
	elif n == 1:
		if int(A[left])>int(A[right]):
			return A[right], A[left]
		else:
			return A[left], A[right]

	middle = (left+right)//2

	T= min_max2(A, left, middle)
	TT = map(int,T)
	ma,Ma = TT
	#print(ma,Ma)
	
	T = min_max2(A, middle+1, right)
	TT = map(int,T)
	mb, Mb = TT
	#print(mb,Mb)
	
	if Ma>Mb:
		if ma>mb:
			return mb,Ma
		else:
			return ma,Ma
	else:
		if ma>mb:
			return mb,Mb
		else:
			return ma,Mb
	# 최소값과 최대값을 리턴한다

A = input().split()
# n개의 정수를 읽어 A에 저장
m, M = min_max2(A, 0, len(A)-1)
print(m, M)