def fractional_knapsack(n, size, profit, K):
	# n개의 아이템, 크기 size[], 가치 profit[], 배낭의 현재 빈 공간 K
	if K <= 0: return 0
	
	s = 0
	p = 0 
	
	for i in range(n):
		if s + size[i] <= K: # 배낭에 쏙 들어가면 전체 선택
			p += profit[i]
			s += size[i]
		else: # 넘치면 잘라서 선택
			p += (K-s) * (profit[i]/size[i])
			s = K
			break
	return p

#-----------------------------------------------------------------------------------------

def Knapsack(i, T): # x[i] = 1인 경우와 0인 경우를 각각 시도함
	global MaxProfit
	global x
	global solution
	
	# T는 배낭의 남은 공간을 의미함
	if i >= n or T <= 0: 
		summation = 0
		for l in range(n):
			summation = summation + (profit[l]*x[l])
		solution.append(summation)
		return
	
	#	s, p = 현재 상태에서 선택된 크기 합, 가치 합
	s = 0
	p = 0
	for j in range(i):
		s = s + size[j]*x[j]
		p = p + profit[j]*x[j]
	
	# 아이템 i를 선택하여 배낭에 넣는 경우: x[i] = 1 이라면?
	# i+1 이후 아이템에 대해, 남은 배낭공간(T-size[i])에 fractional로 채울 수 있는 최대 가치 계산
	#x[i] = 1인 경우
	if size[i] <= T: # 계속 탐색해야 한다면
		B = fractional_knapsack(n-(i+1), size[i+1:], profit[i+1:], T-size[i])
		if (p + profit[i] + B) > MaxProfit: # 계속 탐색을 해야 한다면
			x[i] = 1
			MaxProfit = max(MaxProfit,p+profit[i])
			Knapsack(i+1, T-size[i])
	else:
		for v in range(n-i):
			x[i+v] = 0
		Knapsack(5, 0)
	# 아이템 i를 선택하지 않는 경우: x[i] = 0 이라면?
	#x[i] = 0인 경우
	B = fractional_knapsack(n-(i+1), size[i+1:], profit[i+1:], T)
	if (p + B) > MaxProfit: # 계속 탐색해야 한다면
		x[i] = 0
		Knapsack(i+1, T)
	else:
		for v in range(n-i):
			x[i+v] = 0
		Knapsack(5, 0)
	
'''
1. n, size, profit, K 입력으로 주어짐
2. x = [0, 0, ..., 0] # 아이템 i가 선택되면 x[i] = 1, 아니면 x[i] = 0이 됨
3. MaxProfit = 현재까지 가장 큰 가치 값 [전역변수]
4. solution = [] [전역변수]
4. Knapsack(0, K) # [주의] 아이템의 번호가 0부터 시작한다고 가정!
'''
#------------------------------------------------------------------------------------------

K = int(input())
n = int(input())
size = [int(x) for x in input().split()]
profit = [int(x) for x in input().split()]

# 주어진 아이템을 가성비로 정렬
sorting = []*n
sorting = [[profit[l]/size[l],size[l],profit[l]]for l in range(n)]
srtd = sorted(sorting, key = lambda x : (-x[0]))
for j in range(n):
	size[j] = srtd[j][1]
	profit[j] = srtd[j][2]

MaxProfit = 0
x=[0]*n
solution = []

Knapsack(0,K)
ks = max(solution)
print(ks)
