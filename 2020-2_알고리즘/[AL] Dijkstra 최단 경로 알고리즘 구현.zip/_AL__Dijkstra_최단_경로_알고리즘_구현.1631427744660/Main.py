def heapify_up(A, k, n): 
	while 2*k+1 < n:
		L, R = 2*k + 1, 2*k + 2
		if L < n and A[L][1] < A[k][1]: 
			m = L
		else: 
			m = k
		if R < n and A[R][1] < A[m][1]: 
			m = R
		if m != k:
			A[k][1], A[m][1] = A[m][1], A[k][1]
			A[k][0], A[m][0] = A[m][0], A[k][0]
			k = m
		else: break

def make_heap(n,A):
	for k in range(n-1, -1, -1): # A[0] → ... → A[n-1]
		heapify_up(A, k, n)

def deleteMin(H):
	u = H[0][0]
	del H[0]
	return u

def decreaseKey(n, H, v, distv):
	#v, dist[v]로 변한 값 입력
	n-=1
	for i in range(n):
		if H[i][0] = v:
			H[i][1] = distv
	H = make_heap(n,H)#heap 재배열

def Dijkstra(n, m, G):
	s = 0   #source node, simply 0
	dist = [[j,float('inf')] for j in range(n)]
	dist[0][1] = 0
	parent[0] = 0
	
	H = make_heap(n,dist)
	
	while len(H): # n iterations
		u, distu = deleteMin(H)
		for i in range(m):
			if u = G[i][0]:
				if dist[u][1] + G[i][2] < dist[G[i][1]]: #d[u] + cost(u, v) < d[v] => relax
					dist[G[i][1]] = dist[u][1] + G[i][2]
					parent[G[i][1]] = u
					decreaseKey(n, H, G[i][1], dist[G[i][1]])
	return dist, parent


#****************************************************************************

n = int(input())
m = int(input())
G=[]
for i in range(m):
    G.append(list(map(int, input().split())))



'''for i in range(n):
	for j in range(3):
		print(G[i][j], end=' ')
	print('')
print(G)'''

a, b = Dijkstra(n, m, G)
print(a,b)