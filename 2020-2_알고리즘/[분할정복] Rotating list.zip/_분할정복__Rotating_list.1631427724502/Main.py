# 뼈대 코드가 없으니 입력 처리 코드도 직접 작성할 것!
# code here
def finder(A):
	global k
	l = (len(A)+1)//2 #수행시간 3
	if(len(A)>1):
		if (A[0] > A[l]):
			k = k + len(A)//2 #수행시간 3
			return finder(A[0:l])
		else:
			return finder(A[l:len(A)])
	else:
		return k


A = [int(x) for x in input().split()]
k = 0
s = finder(A)
print(s)
# 질문. 본인의 알고리즘의 비교횟수를 분석한 후, Big-O로 표기해보자

# 전체 리스트를 2 덩어리로 쪼개어 각각의 덩어리의 첫번째 요소를 비교하는 알고리즘이다.
# 비교는 리스트에 1개의 요소가 남을때까지 계속되므로 전체 알고리즘의 수행시간은 log_2(n) (n은 리스트의 길이) 로 나타낼 수 있다. 조금 더 구체적으로 분석해보면 최악의 경우 3 log_2(n) + 3의 수행시간을 가진다고 할 수 있다. 나머지는 각각 상수번의 수행만 진행하기 때문에 Big-O표기법을 통해서 표기해보면 ln(n) 로 나타낼 수 있다.