
W = int(input())
words = input().split()
n = len(words)
B = [[0]*n for _ in range(n)]

for i in range(n):
	Sum = 0
	for j in range(i,n):
		Sum = len(words[j]) + j - i
		penalty = (W-Sum)**3
		B[i][j] = penalty
		print('B[',i,'][',j,']',B[i][j])



'''
import math

W = int(input())
words = input().split()
n = len(words)
C = [[0]*n for _ in range(n)]
P = [[0]*n for _ in range(n)]

for q in range(n):
	C[q][q] = len(words[q])

for d in range(1,n):
	for i in range(n-d):
		j = i+d
		C[i][j] = math.inf
		for k in range (i, j):
			lines = C[i][k] + C[k+1][j] + (k-i) + (j-k-1)
			
#			if W > lines:
#				if C[i][j] > lines:
#					C[i][j] = lines
#					penalty = (W-lines)**2
#					P[i][j] = penalty
	

print (C[0][1])
'''
# code below