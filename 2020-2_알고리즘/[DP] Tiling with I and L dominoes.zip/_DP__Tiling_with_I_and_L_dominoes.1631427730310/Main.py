'''
import math

def tiling_method():
	I[1] = 1
	I[2] = 2
	for i in range(3,n+1):
		I[i] = I[i-1] + I[i-2]
	L[1] = 0
	L[2] = 0
	L[3] = 2
	for j in range(4,n+1):
		
	Sum = L[n]
	return Sum
	
n = int(input())
I = [0]*(n+1)
L = [0]*(n+2)
how_many_method = tiling_method()
print(how_many_method)

'''#수학적 점화식을 이용한 방법
import math

def tiling_method():
	M[0] = 1
	M[1] = 1
	M[2] = 2
	for i in range(3,n+1):
		M[i] = 2*M[i-1] + M[i-3]
	return M[n]
	
n = int(input())
M = [0]*(n+1)
how_many_method = tiling_method()
print(how_many_method)
