def find_median_five(L):
	'''
	for i in range(5):
		for j in range(i+1,5):
			if L[j] < L[i]:
				temp = L[i]
				L[i] = L[j]
				L[j] = temp
			else:break
	return L[2]
	'''
	
	A, B = [], []
	if L[0] > L[1]:
		A.append(L[1])
		A.append(L[0])
	else:
		A.append(L[0])
		A.append(L[1])
	
	if L[2] > L[3]:
		B.append(L[3])
		B.append(L[2])
	else:
		B.append(L[2])
		B.append(L[3])
	
	if A[0] < L[4]:
		if A[1] < L[4]:
			A.append(L[4])
		else:
			A.insert(1, L[4])
	else:
		A.insert(0, L[4])
	
	if A[1] > B[0]:
		if A[1] > B[1]:
			return B[1]
		else:
			return A[1]
	else:
		if A[2] > B[0]:
			return B[0]
		else:
			return A[2]

	

def MoM(L, k): # L의 값 중에서 k번째로 작은 수 리턴
	if len(L) == 1: # no more recursion
		return L[0]
	i = 0
	A, B, M, medians = [], [], [], []
	while i+4 < len(L):
		medians.append(find_median_five(L[i: i+5]))
		i=i+5

	if i < len(L) and i+4 >= len(L):
		rest = len(L)-i
		if rest <= 2:medians.append(L[i])
		else:
			if L[i] > L[i+1]:
				st = L[i]
				nd = L[i+1]
			else:
				st = L[i+1]
				nd = L[i]
			for j in range(2,rest):
				if st < L[i+j]:
					nd = st
					st = L[i+j]
			medians.append(nd)

	mom = MoM(medians,len(medians)+1//2)
	for v in L:
		if v < mom:
			A.append(v)
		elif v > mom:
			B.append(v)
		else:
			M.append(v)
	
	
	if len(A) >= k:
		return MoM(A,k)
	elif len(B) > len(L)-k:
		return MoM(B,k-len(A)-len(M))
	else:
		return mom

n, k = input().split()# n과 k를 입력의 첫 줄에서 읽어들인다
n = int(n)
k = int(k)
L = list(map(int,input().split()))# n개의 정수를 읽어들인다. (split 이용 + int로 변환)
print(MoM(L, k))