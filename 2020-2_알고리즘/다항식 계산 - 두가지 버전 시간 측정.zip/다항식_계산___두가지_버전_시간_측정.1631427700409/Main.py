import time, random

def evaluate_n2(A, x):
    # code for O(n^2)-time function
    S = 0
    for i in range(n):
        T = 1
        for j in range(i):
            T = T * x
        K = A[i] * T
        S = S + K

def evaluate_n(A, x):
    # code for O(n)-time function
    T = 1
    S = 0
    for i in range(len(A)):
        K = A[i] * T
        S = S + K
        T = T * x



random.seed()  # random 함수 초기화
n = int(input('n을 입력하시오 : '))# n 입력받음
A = [random.randint(-999,999) for i in range(n)]# 리스트 A를 randint를 호출하여 n개의 랜덤한 숫자로 채움

x = random.randint(-99,99)


before = time.clock()
evaluate_n2(A, x)# evaluate_n2 호출
after = time.clock()
print (after - before)

before = time.clock()
evaluate_n(A, x)# evaluate_n 호출
after = time.clock()
print (after - before)
# 두 함수의 수행시간 출력
