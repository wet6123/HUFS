def pin(FE):
	# code here
	FE.sort(key = lambda x : (x[1])) #막대의 끝점을 기준으로 순서대로 정렬시킨다
	p=1 #핀 개수를 count, 처음하나는 무조건 세준다
	j=0
	for i in range(1,len(FE)):
		if FE[j][1] < FE[i][0]: #끝나는 점보다 앞에 있는 시작점은 pass한다.
			j=i #끝점보다 큰 시작점 값을 가진 막대에 새로운 핀을 꽂는다. 즉,새로운 끝점값으로 바꾸어준다.
			p+=1
	return(p)
# 리스트 A에 구간 n개를 저장 후, pin 함수를 불러 리턴 값을 출력한다
N = int(input())
A=[]

for i in range(N):
	B = [int(x) for x in input().split()]
	A.append([B[0],B[1]])

P = pin(A)
print(P)
#끝부분이 앞에 있는 막대에 부터 핀을 꽂아주는 알고리즘이다.

#수행시간 분석
#막대를 순서대로 정렬하는데 사용한 sort함수의 수행시간은 O(n log(n)).
#for문을 이용해서 막대를 하나씩 비교하는데 걸리는 수행시간이 O(n)이다.
#따라서 이 알고리즘의 수행시간은 O(n log(n))로 표현 할 수 있다.(최악의 경우 nlog(n)+2n+2의 수행시간으로 pin함수가 동작)