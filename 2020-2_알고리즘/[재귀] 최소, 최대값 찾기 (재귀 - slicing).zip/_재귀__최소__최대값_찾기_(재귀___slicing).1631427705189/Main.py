def min_max2(A):
    n = len(A)
    if n == 1:
        #print(A[0])
        return A[0], A[0]
    elif n <= 2:
        #print(A[0], ' ', A[1])
        if int(A[0]) > int(A[1]):
            M = A[0]
            m = A[1]
        else:
            M = A[1]
            m = A[0]
        #print('big', M,'small',m)
        return m, M
    else:
        h_n = n//2
        T = min_max2(A[:h_n])
        TT=map(int,T)
        ma, Ma = TT
        
        T = min_max2(A[h_n:])
        TT = map(int, T)
        mb, Mb = TT

        #print('L', Ma, Mb)
        #print('S',ma, mb)
        if Ma>Mb:
            #print('<', Ma)
            if ma>mb:
                return mb,Ma
            else:
                return ma,Ma
        else:
            #print('>', Mb)
            if ma>mb:
                return mb, Mb
            else:
                return ma, Mb


A = input().split()

m, M = min_max2(A)
print(m,M)