import math
def guess_two_missing_numbers(n, S, T):
	SUM = n*(n+1)/2 #1~n까지의 합, 수행시간 4
	SQUAR_SUM = n*(n+1)*(2*n+1)/6 #1~n까지의 제곱의 합, 수행시간 7
	A = SUM - S #A = a+b, 수행시간 2
	B = SQUAR_SUM - T #B = a^2 + b^2, 수행시간 2
	b = int((A+ math.sqrt(A*A-2*(A*A - B)))/2) #수행시간 9
	a = int(A - b) #수행시간 2
	return a, b  # a < b are two missing numbers

#수행시간은 26으로 항상 변하지 않는다. 따라서 O(26)로 표기할 수 있다.

n = int(input())
S, T = [int(x) for x in input().split()]
a, b = guess_two_missing_numbers(n, S, T)
print(a, b)