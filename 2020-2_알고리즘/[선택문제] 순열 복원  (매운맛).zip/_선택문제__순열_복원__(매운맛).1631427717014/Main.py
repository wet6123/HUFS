def reconstruct(B):
	NUM, A = [], []
	NUM = list(range(0,len(B)))
	
	for i in range(len(B)-1,-1,-1):
		A.insert(0,NUM[B[i]])
		del NUM[B[i]]
	
	return A
	# B로부터 A를 재구성해 리턴
	# 이 함수를 작성합니다~

	
B = [int(x) for x in input().split()]
A = reconstruct(B)
print(A)

# 1. 본인이 작성한 알고리즘의 수행시간을 간략히 분석해보자
# 
# 2. 수행시간 T(n)을 Big-O료 표기해보자
# 